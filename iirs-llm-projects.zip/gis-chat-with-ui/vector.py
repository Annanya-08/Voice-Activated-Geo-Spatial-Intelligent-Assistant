# import
from langchain_chroma import Chroma
from langchain_community.document_loaders import CSVLoader
from langchain_community.embeddings.sentence_transformer import (
    SentenceTransformerEmbeddings,
)
from langchain_text_splitters import CharacterTextSplitter

# create the open-source embedding function
embedding_function = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")

def vectorize_docs():
    # load the document and split it into chunks
    # loader = JSONLoader("complete_data.json",jq_schema='.metadata[].categoryName',)
    loader = CSVLoader(file_path="./data.csv")
    documents = loader.load()
    # split it into chunks
    text_splitter = CharacterTextSplitter(chunk_size=500, chunk_overlap=100)
    docs = text_splitter.split_documents(documents)
    # load it into Chroma
    Chroma.from_documents(docs, embedding_function, persist_directory="chroma")

def format_docs(docs):
    return "\n\n".join(doc.page_content for doc in docs)

def read_docs(query:str):
    # query it
    vector_store = Chroma(persist_directory="./chroma", embedding_function=embedding_function)
    # retriever = vector_store.as_retriever(search_type="similarity", search_kwargs={"k": 6})
    # retrieved_docs = retriever.invoke("agriculture")
    docs = vector_store.similarity_search(query, k=30)
    return format_docs(docs)


if __name__ == "__main__":
    print(read_docs("agriculture"))