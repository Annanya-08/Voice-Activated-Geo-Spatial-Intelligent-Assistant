import whisper

#Import the required libraries
from langchain_community.chat_models import ChatOllama,ChatOpenAI
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.messages import AIMessage
from langchain_google_genai import ChatGoogleGenerativeAI

#open json file  
import json

model = whisper.load_model("medium")

def execute_query(query:str):
    with open('complete_data.json') as f:
        metadata = json.load(f)

    example1 = """
    <categories>
        <category>
            <name>category1</name>
            <layers>
                <layer>layer1A</layer>
                <layer>layer2A</layer>
            </layers>
        </category>
    </categories>
    """
    example2 = """
    <categories>
        <category>
            <name>category2</name>
            <layers>
                <layer>layer1B</layer>
                <layer>layer2B</layer>
            </layers>
        </category>
    </categories>
    """

    # install ollama to use this one
    # llm = ChatOllama(model="llama3.1:8b",base_url="http://localhost:11434",temperature=0.3,num_ctx=12800)

    # goto nvidia's ai platform for getting api keys

    # llm = ChatOpenAI(model="meta/llama3-70b-instruct",base_url = "https://integrate.api.nvidia.com/v1",api_key="")
    # llm = ChatOpenAI(model="meta/llama-3.1-405b-instruct",base_url = "https://integrate.api.nvidia.com/v1",api_key="")

    # gemini api keys can be obtained from the ai studio by google
    llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash-latest",api_key="")

    #write a prompt to extract a list of keywords from the users query
    prompt1="""
    <s>[INST] <<SYS>>Be a geo spatial data expert and follow following instructions to answer the users query:
    <|USER_QUERY:START|>
    {query}
    <|USER_QUERY:END|>
    ------------------------
    <|CATEGORY_AND_LAYER_DATA:START|>
    {metadata}
    <|CATEGORY_AND_LAYER_DATA:END|>
    ------------------------
    <|INSTRUCTIONS:START|>
    - Analyze the user's query. 
    - If the user query is not related to anything which you think is of Geospatial Layers domain then reply return a category named "NA" with layer named "NO LAYER CAN BE ACTIVATED"
    - Identify which categories and layers are to be activated based on the user's query.
    - Only return the layers that are relevant for answering the user's query.
    - Do not include any other message.
    - Do not make up things.
    - Use the exact category and layers names as in the CATEGORY AND LAYER DATA.
    - Follow the schema used in the examples below to respond.
    <|INSTRUCTIONS:END|>
    ----------------------------
    <EXAMPLES>
        <|EXAMPLE_1:START>
            {example1}
        <|EXAMPLE_1:END>
        <|EXAMPLE_2:START>
            {example2}
        <|EXAMPLE_2:END>    
    </EXAMPLES|>
    [/INST]
    </s>
    """
    d = {"query": query,"metadata":metadata,"example1":example1,"example2":example2}
    filled_prompt = prompt1.format(**d)
    with open("p.txt", 'w') as f:
        f.write(filled_prompt)
    output = ChatPromptTemplate.from_template(prompt1)
    global chain 
    chain = output | llm | StrOutputParser()
    result = analyze_query(query,metadata,example1,example2)
    return result

def transcribe_audio_file(audio_file_path):
    # model = whisper.load_model("large")
    result = model.transcribe(audio_file_path)
    return result["text"]

def analyze_query(query,metadata,example1,example2):
    response = chain.invoke({"query": query,"metadata":metadata,"example1":example1,"example2":example2})
    return response

if __name__ == "__main__":
    print(execute_query("Activate hospitals and roads layers. "))
