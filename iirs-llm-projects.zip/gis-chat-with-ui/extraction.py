import re
import json
xml_string = """
<categories>
  <category>
    <name>Land Use Land Cover-2021-22(1:10K)</name>
    <layers>
      <layer>River/Stream/Canals</layer>
      <layer>River/Stream/Canals</layer>
    </layers>
  </category>
  <category>
    <name>frdt5fdgtdtdtLand Use Land Cover-2021-22(1:10K)</name>
    <layers>
      <layer>River/Stream/Canals</layer>
      <layer>River/Stream/asdasdasdas</layer>
    </layers>
  </category>
</categories>
"""
def extract_jsontags(xml_string):
    #print(re.findall(r'<categories>(.*?)</categories>',xml_string,re.DOTALL))
    categories=re.findall(r'<categories>(.*?)</categories>',xml_string,re.DOTALL)
    categories_json=[]
    for category in categories:
        #print(category)
        category_match=re.findall(r'<category>(.*?)</category>',category,re.DOTALL)
        #print(i)
        if len(category_match)>0:
            for category_xml in category_match:
              #print(category_match.group())
              category_json={}
              name_match=re.search(r'<name>(.*?)</name>',category_xml)
              if name_match:
                      category_json['name']=name_match.group(1)
              layers_match=re.search(r'<layers>(.*?)</layers>',category_xml,re.DOTALL)
              if layers_match:
                  layers_xml=layers_match.group(1)
                  layers_json=[]
                  for layer_match in re.finditer(r'<layer>(.*?)</layer>', layers_xml):
                      layers_json.append(layer_match.group(1))
                  category_json['layers'] = layers_json
              categories_json.append(category_json)
    # return json.dumps({'categories': categories_json},indent=4)
    return {'categories': categories_json}
# print(extract_jsontags(xml_string))