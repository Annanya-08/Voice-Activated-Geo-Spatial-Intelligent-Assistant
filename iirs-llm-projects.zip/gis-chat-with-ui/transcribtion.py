# !pip install langchain_community
# !pip install langchain_core

#Import the required libraries
from langchain_community.chat_models import ChatOllama
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.messages import AIMessage

#open json file  
import json

#open whisper model
import helpers

with open('partial_data.json') as f:
    metadata = json.load(f)

example1 = """
<categories>
    <category>
        <name>category1</name>
        <layers>
            <layer>layer1A</layer>
            <layer>layer2A</layer>
        </layers>
    </category>
</categories>
"""
example2 = """
<categories>
    <category>
        <name>category2</name>
        <layers>
            <layer>layer1B</layer>
            <layer>layer2B</layer>
        </layers>
    </category>
</categories>
"""

llm = ChatOllama(model="mixtral:latest",base_url="http://localhost:11434/")
#write a prompt to extract a list of keywords from the users query
prompt1="""
<s>[INST] <<SYS>>Be a geo spatial data expert and follow following instructions to answer the users query:
<|USER_QUERY:START|>
{query}
<|USER_QUERY:END|>
------------------------
<|CATEGORY_AND_LAYER_DATA:START|>
{metadata}
<|CATEGORY_AND_LAYER_DATA:END|>
------------------------
<|INSTRUCTIONS:START|>
- Analyze the user's query. 
- Identify which categories and layers are to be activated based on the user's query.
- Only return the layers that are relevant for answering the user's query.
- Do not include any other message.
- Do not make up things.
- Use the exact category and layers names as in the CATEGORY AND LAYER DATA.
- Follow the schema used in the examples below to respond.
<|INSTRUCTIONS:END|>
----------------------------
<EXAMPLES>
    <|EXAMPLE_1:START>
        {example1}
    <|EXAMPLE_1:END>
    <|EXAMPLE_2:START>
        {example2}
    <|EXAMPLE_2:END>    
</EXAMPLES|>
[/INST]
</s>
"""
output = ChatPromptTemplate.from_template(prompt1)

def analyze_query(query,metadata,example,example2):
    response = chain.invoke({"query": query,"metadata":metadata,"example1":example1,"example2":example2})
    return response

# Run the prompt
chain = output | llm | StrOutputParser()
query = helpers.transcribe_audio_file('./audio_files/BESu7zIuxI.wav')
result = analyze_query(query, metadata, example1, example2)
print(result)

