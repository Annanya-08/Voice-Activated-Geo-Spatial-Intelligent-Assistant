from langchain_chroma import Chroma
from langchain_community.document_loaders import CSVLoader
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.embeddings.sentence_transformer import (
    SentenceTransformerEmbeddings,
)
from langchain_text_splitters import CharacterTextSplitter
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnableParallel, RunnablePassthrough
from langchain_community.chat_models import ChatOllama,ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate


# create the open-source embedding function
embedding_function = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")

def vectorize_docs():
    # load the document and split it into chunks
    # loader = JSONLoader("complete_data.json",jq_schema='.metadata[].categoryName',)
    loader = CSVLoader(file_path="./data.csv")
    documents = loader.load()
    # split it into chunks
    text_splitter = CharacterTextSplitter(chunk_size=500, chunk_overlap=100)
    docs = text_splitter.split_documents(documents)
    # load it into Chroma
    Chroma.from_documents(docs, embedding_function, persist_directory="chroma")

def format_docs(docs):
    formattedDOcs =  "\n----\n".join(doc.page_content for doc in docs)
    return formattedDOcs

def read_docs(query: str):
    # query it
    vector_store = Chroma(persist_directory="./chroma", embedding_function=embedding_function)
    docs = vector_store.similarity_search(query, k=100)
    return docs


vector_store = Chroma(persist_directory="./chroma", embedding_function=embedding_function)
retriever = vector_store.as_retriever(search_type="similarity", search_kwargs={"k":50})

template = """Answer the question based only on the following context as per:
{context}

Question: {question}
"""

prompt = ChatPromptTemplate.from_template(template)
# llm = ChatOpenAI(model="meta/llama3-8b-instruct", base_url="https://integrate.api.nvidia.com/v1", api_key="")
# llm = ChatOllama(model="llama3:instruct", base_url="http://localhost:11434")
llm = ChatOllama(model="mixtral:latest", base_url="http://localhost:11434")
rag_chain = (
     RunnableParallel({"context": retriever | format_docs , "question": RunnablePassthrough()})
    | prompt.invoke
    | llm
    | StrOutputParser()
)

if __name__ == "__main__":
    # vectorize_docs()
    for chunk in rag_chain.stream("Give list of all the agriculture layers"):
        print(chunk, end="", flush=True)
