from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import os
from helpers import transcribe_audio_file, execute_query
from extraction import extract_jsontags

if "GOOGLE_API_KEY" not in os.environ:
    # get it from ai studio by google
    os.environ["GOOGLE_API_KEY"] = ""

app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = 'audio_files'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('chat.html')

@app.route("/stt", methods=["POST"])
def stt():
    if 'audio' not in request.files:
        return jsonify({'error': 'No audio file provided'}), 400
    audio_file = request.files['audio']
    audio_path = os.path.join(UPLOAD_FOLDER, audio_file.filename)
    audio_file.save(audio_path)    
    text = transcribe_audio_file(audio_path)
    return {"text": text}

@app.route('/chat', methods=['POST'])
def upload_audio():
    result = extract_jsontags(execute_query(request.json["query"]))
    return jsonify({'message': 'Query executed!', "query": request.json["query"], "result": result }), 200

if __name__ == '__main__':
    app.run(debug=True, port=9999, host="0.0.0.0")