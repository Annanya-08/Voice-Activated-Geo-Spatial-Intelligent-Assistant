import whisper

model = whisper.load_model("large")

def transcribe_audio_file(audio_file_path):
    # model = whisper.load_model("large")
    result = model.transcribe(audio_file_path)
    return result["text"]
print(transcribe_audio_file('./audio_files/1.wav'))